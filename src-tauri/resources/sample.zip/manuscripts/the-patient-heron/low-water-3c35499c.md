---
id: 8db6cd9d-94e3-44f7-a0f8-a911d87be173
title: Low Water
kind: chapter
updated: 2026-11-14T01:45:04Z
---

The tide went out farther than anyone in Silvermere could remember, and [Elyran](entity://6590e1a3-cb60-4d83-917b-82681be8c958#written) went out with it.
"Mark it," said Mira. "Mark *everything*."
The mud shone all the way to the reef. Ships she had known all her life lay on their sides like tired animals.