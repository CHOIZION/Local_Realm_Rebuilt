---
id: 448924fb-09e8-40e9-919f-4d48c9cb15aa
title: The Forged Chart
kind: chapter
updated: 2026-11-14T01:45:04Z
---

The chart was beautiful, which was the first sign it was a lie.
She laid her own soundings over it, line by line, until the lie had a shape.