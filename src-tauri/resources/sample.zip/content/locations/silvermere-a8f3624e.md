---
id: ab862627-72ac-4565-a1bb-dfc598ba52a9
entity: a8f3624e-d5f7-4c57-a5cb-c4325c2cd1b3
title: Silvermere
kind: article
updated: 2026-11-14T01:45:04Z
---

Silvermere stands on ten thousand stilts over the mouths of the river, where [the Reach](entity://426308b8-9cc1-4fed-91e4-b21ad83a2ac4#written) meets the sea.
| District | Known for |
| --- | --- |
| Lowmarket | fish and rumours |
| The Stilts | mapmakers |
The archive of [The Ember Compact](entity://88b2181b-0676-480e-81b3-203322e5be52) sits above the tide line, the only stone building in the city.