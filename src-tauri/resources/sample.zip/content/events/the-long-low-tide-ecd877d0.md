---
id: 2049f6ac-583d-4c37-9b24-bc6fece04df4
entity: ecd877d0-4318-4535-a8ce-a83e3b5fca9c
title: The Long Low Tide
kind: article
updated: 2026-11-14T01:45:04Z
---

For a whole season the sea stood half a mile out from [Silvermere](entity://a8f3624e-d5f7-4c57-a5cb-c4325c2cd1b3). Ships sat on the mud, and old wrecks came up out of the silt.
[Elyran](entity://6590e1a3-cb60-4d83-917b-82681be8c958) walked out to the shoals and measured them.