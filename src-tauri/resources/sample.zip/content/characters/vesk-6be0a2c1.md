---
id: 62d2443f-b1c3-4cca-b45e-1a31761288d0
entity: 6be0a2c1-a22b-485b-8d49-4dbac10b0a5a
title: Vesk
kind: article
updated: 2026-11-14T01:45:04Z
---

