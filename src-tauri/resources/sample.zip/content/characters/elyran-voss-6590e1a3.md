---
id: f501e0cd-3bb4-4f64-a170-1412db1699db
entity: 6590e1a3-cb60-4d83-917b-82681be8c958
title: Elyran Voss
kind: article
updated: 2026-11-14T01:45:04Z
---

## Early life
Elyran was born in [the river city](entity://a8f3624e-d5f7-4c57-a5cb-c4325c2cd1b3#written) to [Corin Voss](entity://e7835100-5c7c-4431-81ed-996a595eb310) and [Isa Voss](entity://9741494d-35c7-4154-93ae-2eec4aab63d4), and learned the channels before she could read.
At twelve she was given to [Mira Ashdown](entity://54007e6b-88fd-40ad-aea0-74b1514da522) as an apprentice, and spent the next ten years copying charts in the archive of [The Ember Compact](entity://88b2181b-0676-480e-81b3-203322e5be52).
## The forged chart
During [the Long Low Tide](entity://ecd877d0-4318-4535-a8ce-a83e3b5fca9c#written) she sounded the northern shoals herself and found that the Compact's chart of them was **wrong on purpose**.
*Someone wanted ships on the reef.*
She has been hunted by [Vesk](entity://6be0a2c1-a22b-485b-8d49-4dbac10b0a5a) ever since.