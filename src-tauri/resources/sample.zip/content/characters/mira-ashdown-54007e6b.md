---
id: e8457013-7663-4791-bd5b-261baba8cc51
entity: 54007e6b-88fd-40ad-aea0-74b1514da522
title: Mira Ashdown
kind: article
updated: 2026-11-14T01:45:04Z
---

[Old Mira](entity://54007e6b-88fd-40ad-aea0-74b1514da522#written) taught [Elyran](entity://6590e1a3-cb60-4d83-917b-82681be8c958) everything she knows about tides.