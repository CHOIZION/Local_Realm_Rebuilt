---
id: 7b48c3bd-1cb7-4dfd-bdcc-e820342bf638
title: Start here
kind: note
updated: 2026-11-14T01:45:04Z
---

# Welcome to the sample realm
Everything here was made with the app, and you can change or delete any of it.
- Open [Elyran Voss](entity://6590e1a3-cb60-4d83-917b-82681be8c958) to see an article with an infobox, links and a family.
- Open the map **The Ashen Reach** and the timeline **History of the Reach**.
- Open the tree **House Voss** to see the family laid out.
- Open the manuscript **The Patient Heron** to see chapters, page counts and the manuscript export.
When you are ready, start your own realm from the realm list.