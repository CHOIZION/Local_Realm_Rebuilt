---
id: e362b494-232a-46e3-8065-771c45a8c3d8
entity: 88b2181b-0676-480e-81b3-203322e5be52
title: The Ember Compact
kind: article
updated: 2026-11-14T01:45:04Z
---

A guild of cartographers sworn to hide the safe routes through the reefs. Its leader is [Mira Ashdown](entity://54007e6b-88fd-40ad-aea0-74b1514da522).
> What is charted is kept.
Members swear on a blank chart, which they are buried with.